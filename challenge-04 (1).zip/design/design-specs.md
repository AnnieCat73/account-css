# Challenge #4

## Colors

- neutral-100: #fff
- neutral-300: #A9AFBC;
- neutral-400: #737B8C
- neutral-900: #020203

- primary-400: #FF3369

## Typography

### Fonts: 

- Poppins
  - Light
  - Regular
  - Medium
  - Extra Bold

### Font sizes:

- title: 22px
- form labels and other text: 12px
- form placeholder: 16px
- button: 20px

